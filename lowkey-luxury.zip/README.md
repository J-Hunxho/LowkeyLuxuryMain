# Lowkey Luxury

A top-tier, AI-powered text consultancy application. Features a "Quiet Luxury" black and gold aesthetic, particle animations, and a real-time Gemini-powered consultant.

## Tech Stack
- **Frontend:** React 18, TypeScript, Tailwind CSS
- **AI:** Google Gemini API (`@google/genai`)
- **Build Tool:** Vite (Recommended for Railway)

## Prerequisites
1. A Google Cloud Project with the Gemini API enabled.
2. A valid API Key from Google AI Studio.
3. A GitHub account.
4. A Railway account.

## Setup & Deployment to Railway

### 1. Repository Setup
Push this code to a new GitHub repository. Ensure the file structure is at the root.

### 2. Connect to Railway
1. Log in to [Railway](https://railway.app/).
2. Click **New Project** > **Deploy from GitHub repo**.
3. Select your `Lowkey Luxury` repository.

### 3. Environment Variables
Before the build completes (or in the Settings tab after creation):
1. Go to the **Variables** tab in your Railway project.
2. Add the following variable:
   - `API_KEY`: Paste your Google Gemini API Key here.

### 4. Build Settings
Railway usually auto-detects Vite projects. If you need to configure it manually in **Settings > Build**:
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
- **Install Command:** `npm install`

### 5. Access
Once deployed, Railway will provide a public domain (e.g., `lowkey-luxury-production.up.railway.app`).

## Development

To run locally:

1. Create a `.env` file in the root:
   ```
   API_KEY=your_actual_api_key
   ```
2. Install dependencies:
   ```bash
   npm install react react-dom @google/genai tailwindcss postcss autoprefixer
   ```
   *(Note: You'll need to set up Vite or CRA configuration if running locally from scratch, but the code provided is ready for a standard React environment).*

3. Run the development server.

## Features
- **Luxe Consultant:** An AI persona engineered for high-end text consulting.
- **Visuals:** HTML5 Canvas Gold Particle system.
- **Social Proof:** Interactive review carousel with problem/resolution breakdowns.
