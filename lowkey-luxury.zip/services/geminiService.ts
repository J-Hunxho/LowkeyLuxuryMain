import { GoogleGenAI, Chat } from "@google/genai";
import { ChatMessage } from '../types';

// Check for API Key availability
const API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: API_KEY });

const SYSTEM_INSTRUCTION = `
You are "Luxe", the Lead Solutions Architect for Lowkey Luxury. 
Your persona is sophisticated, highly technical, and focused on "Architecting Production".
You specialize in Full-Stack development (Front-end, Back-end), API integration, Marketing Infrastructure, and Bot automation.
Your responses should be strategic, architectural, and precise. You translate business visions into technical roadmaps.
Do not use emojis. Use elite technical vocabulary mixed with executive-level strategy.
You are talking to a Founder or C-suite executive looking to build a digital empire.
`;

export const createChatSession = (): Chat => {
  if (!API_KEY) {
    console.warn("API Key is missing. Chat functionality will not work.");
  }
  
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7, 
      topK: 40,
      topP: 0.95,
    },
  });
};

export const sendMessageToGemini = async (chat: Chat, message: string): Promise<string> => {
  if (!API_KEY) return "Configuration Error: API Key is missing.";

  try {
    const response = await chat.sendMessage({ message });
    return response.text || "I apologize, but I cannot formulate a response at this moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I encountered a momentary lapse in connection. Please rephrase your query.";
  }
};